﻿using System;
using System.Collections.Generic;

public class OCDirection
{

	public OCDirection(){}

    public void newOCDirection(int routeNo, String routeLabel, String direction, String procTime, List<OCTrip> trips)
    {
        this.RouteNo = routeNo;
        this.RouteLabel = routeLabel;
        this.Direction = direction;
        this.ProcTime = procTime;
        this.Trips = trips;
    }

    public int RouteNo { get; set; }
    public String RouteLabel { get; set; }
    public String Direction { get; set; }
    public String ProcTime { get; set; }
    public List<OCTrip> Trips { get; set; }
}
